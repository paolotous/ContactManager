﻿CREATE TABLE [dbo].[tblContacts]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [First Name] NVARCHAR(50) NOT NULL, 
    [Last Name] NVARCHAR(50) NOT NULL, 
    [Email] NVARCHAR(50) NOT NULL, 
    [Street Address] NCHAR(10) NULL, 
    [Birthday] NCHAR(10) NULL, 
    [Notes] NCHAR(10) NULL
)
